import CONFIG from '../config.json'
export const SITE = CONFIG

